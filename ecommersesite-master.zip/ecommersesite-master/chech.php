<?php
while(1){
  echo "loop executed
";
}
?>